-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2020 at 04:44 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `algoritma_ahp`
--

-- --------------------------------------------------------

--
-- Table structure for table `alternatif`
--

CREATE TABLE `alternatif` (
  `id_alternatif` int(11) NOT NULL,
  `nama_alternatif` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alternatif`
--

INSERT INTO `alternatif` (`id_alternatif`, `nama_alternatif`) VALUES
(1, 'Andik Saputra'),
(2, 'Bagus Venanda'),
(3, 'Candra Pustpita Dewi'),
(4, 'Dia Primasari'),
(5, 'Eka Mulyani'),
(6, 'Faishol Azizi');

-- --------------------------------------------------------

--
-- Table structure for table `alternatif_nilai`
--

CREATE TABLE `alternatif_nilai` (
  `id_alternatif_nilai` int(11) NOT NULL,
  `id_alternatif` int(11) NOT NULL,
  `id_kriteria` int(11) NOT NULL,
  `nilai` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alternatif_nilai`
--

INSERT INTO `alternatif_nilai` (`id_alternatif_nilai`, `id_alternatif`, `id_kriteria`, `nilai`) VALUES
(1, 1, 1, '6'),
(2, 1, 2, '4'),
(3, 1, 3, '3'),
(4, 2, 1, '6'),
(5, 2, 2, '7'),
(6, 2, 3, '4'),
(7, 3, 1, '5'),
(8, 3, 2, '6'),
(9, 3, 3, '7'),
(10, 4, 1, '5'),
(11, 4, 2, '8'),
(12, 4, 3, '7'),
(13, 5, 1, '6'),
(14, 5, 2, '6'),
(15, 5, 3, '6'),
(16, 6, 1, '7'),
(17, 6, 2, '7'),
(18, 6, 3, '4'),
(19, 1, 4, ''),
(20, 1, 5, '');

-- --------------------------------------------------------

--
-- Table structure for table `kriteria`
--

CREATE TABLE `kriteria` (
  `id_kriteria` int(11) NOT NULL,
  `kode_kriteria` varchar(100) NOT NULL,
  `nama_kriteria` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kriteria`
--

INSERT INTO `kriteria` (`id_kriteria`, `kode_kriteria`, `nama_kriteria`) VALUES
(1, '01-KM', 'Kemampuan Mengajar'),
(2, '02-S', 'Sikap'),
(3, '03-JK', 'Jumlah Karya');

-- --------------------------------------------------------

--
-- Table structure for table `kriteria_bobot`
--

CREATE TABLE `kriteria_bobot` (
  `id_kriteria_bobot` int(11) NOT NULL,
  `id_ka` int(11) NOT NULL,
  `id_kb` int(11) NOT NULL,
  `jumlah_bobot` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kriteria_bobot`
--

INSERT INTO `kriteria_bobot` (`id_kriteria_bobot`, `id_ka`, `id_kb`, `jumlah_bobot`) VALUES
(1, 1, 1, '1'),
(2, 1, 2, '9'),
(3, 2, 1, '0.11111111111111'),
(4, 2, 2, '1'),
(5, 1, 3, '5'),
(7, 2, 3, '4'),
(9, 3, 1, '0.2'),
(10, 3, 2, '0.25'),
(11, 3, 3, '1');

-- --------------------------------------------------------

--
-- Table structure for table `subkriteria`
--

CREATE TABLE `subkriteria` (
  `id_subkriteria` int(11) NOT NULL,
  `nama_subkriteria` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subkriteria`
--

INSERT INTO `subkriteria` (`id_subkriteria`, `nama_subkriteria`) VALUES
(1, 'Sangat Baik'),
(2, 'Baik'),
(3, 'Cukup'),
(4, 'Kurang');

-- --------------------------------------------------------

--
-- Table structure for table `subkriteria_bobot`
--

CREATE TABLE `subkriteria_bobot` (
  `id_subkriteria_bobot` int(11) NOT NULL,
  `id_ska` int(11) NOT NULL,
  `id_skb` int(11) NOT NULL,
  `jumlah_bobot` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subkriteria_bobot`
--

INSERT INTO `subkriteria_bobot` (`id_subkriteria_bobot`, `id_ska`, `id_skb`, `jumlah_bobot`) VALUES
(1, 1, 1, '1'),
(2, 1, 2, '3'),
(3, 1, 3, '7'),
(4, 1, 4, '9'),
(5, 2, 1, '0.33'),
(6, 2, 2, '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alternatif`
--
ALTER TABLE `alternatif`
  ADD PRIMARY KEY (`id_alternatif`);

--
-- Indexes for table `alternatif_nilai`
--
ALTER TABLE `alternatif_nilai`
  ADD PRIMARY KEY (`id_alternatif_nilai`);

--
-- Indexes for table `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`id_kriteria`);

--
-- Indexes for table `kriteria_bobot`
--
ALTER TABLE `kriteria_bobot`
  ADD PRIMARY KEY (`id_kriteria_bobot`);

--
-- Indexes for table `subkriteria`
--
ALTER TABLE `subkriteria`
  ADD PRIMARY KEY (`id_subkriteria`);

--
-- Indexes for table `subkriteria_bobot`
--
ALTER TABLE `subkriteria_bobot`
  ADD PRIMARY KEY (`id_subkriteria_bobot`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alternatif`
--
ALTER TABLE `alternatif`
  MODIFY `id_alternatif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `alternatif_nilai`
--
ALTER TABLE `alternatif_nilai`
  MODIFY `id_alternatif_nilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `kriteria`
--
ALTER TABLE `kriteria`
  MODIFY `id_kriteria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `kriteria_bobot`
--
ALTER TABLE `kriteria_bobot`
  MODIFY `id_kriteria_bobot` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `subkriteria`
--
ALTER TABLE `subkriteria`
  MODIFY `id_subkriteria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `subkriteria_bobot`
--
ALTER TABLE `subkriteria_bobot`
  MODIFY `id_subkriteria_bobot` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
